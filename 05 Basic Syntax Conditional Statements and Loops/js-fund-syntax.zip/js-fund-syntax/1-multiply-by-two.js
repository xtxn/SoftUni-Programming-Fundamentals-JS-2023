function solve(number) {
    console.log(number * 2);
}

solve(2);
solve(5);
solve(20);
