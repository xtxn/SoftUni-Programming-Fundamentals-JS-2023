function solve(max, min) {
    for (let i = max; i >= min; i--) {
        console.log(i);
    }
}

solve(6, 2);
