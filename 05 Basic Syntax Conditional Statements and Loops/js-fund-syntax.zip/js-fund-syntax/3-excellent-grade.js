function showGrade(number) {
    if (number >= 5.5) {
        console.log('Excellent');
    } else {
        console.log('Not excellent');
    }
}

showGrade(5.5);
showGrade(4.35);
