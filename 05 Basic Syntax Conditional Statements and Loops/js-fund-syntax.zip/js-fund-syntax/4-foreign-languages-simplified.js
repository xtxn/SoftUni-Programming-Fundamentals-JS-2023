function solve(country) {
    if (country == 'USA' || country == 'England') {
        console.log('English');
    } else if (country == 'Spain' || country == 'Mexico' || country == 'Argentina') {
        console.log('Spanish');
    } else {
        console.log('unknown');
    }
}
