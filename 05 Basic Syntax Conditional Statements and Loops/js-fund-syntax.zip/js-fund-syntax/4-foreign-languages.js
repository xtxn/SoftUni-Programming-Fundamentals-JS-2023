function solve(country) {
    if (country == 'USA') {
        console.log('English');
    } else if (country == 'England') {
        console.log('English');
    } else if (country == 'Spain') {
        console.log('Spanish');
    } else if (country == 'Mexico') {
        console.log('Spanish');
    } else if (country == 'Argentina') {
        console.log('Spanish');
    } else {
        console.log('unknown');
    }
}
