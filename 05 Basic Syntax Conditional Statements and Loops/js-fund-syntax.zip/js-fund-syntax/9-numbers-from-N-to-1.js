function solve(number) {
    let currentNumber = number;

    while(currentNumber >= 1) {
        console.log(currentNumber);
        currentNumber--;
    }
}

solve(5);
