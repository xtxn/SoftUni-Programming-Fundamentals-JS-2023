function solve() {
    console.log('Hello World!');
}

solve();
