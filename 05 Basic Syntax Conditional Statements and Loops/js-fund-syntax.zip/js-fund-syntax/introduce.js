function introduce(name, age) {
    // let introduction = 'Hello my name is ' + name + ' and I\'m ' + age + ' years old!';
    let introduction = `Hello my name is ${name} and I'm ${age} years old`;

    console.log(introduction);
}

introduce('Pesho', 20);
introduce('Gosho', 21);
